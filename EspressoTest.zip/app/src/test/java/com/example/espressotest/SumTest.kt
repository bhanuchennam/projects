package com.example.espressotest

import io.mockk.every
import io.mockk.mockkObject
import org.junit.Assert.assertEquals
import org.junit.Test

class SumTest {

    @Test
    fun test_sum() {
        mockkObject(Sum) // applies mocking to an Object

        assertEquals(3, Sum.add(1, 2))

        every { Sum.add(1, 2) } returns 55

        assertEquals(55, Sum.add(1, 2))
    }
}
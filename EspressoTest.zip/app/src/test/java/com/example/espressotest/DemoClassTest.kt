package com.example.espressotest

import android.content.Context
import io.mockk.MockKAnnotations
import io.mockk.every
import io.mockk.impl.annotations.MockK
import io.mockk.spyk
import org.junit.Assert
import org.junit.Before
import org.junit.Test

class DemoClassTest {
    @MockK
    lateinit var context: Context

    @Before
    fun setup(){
        MockKAnnotations.init(this)
    }

    @Test
    fun test_string(){

        val exampleClass = spyk(DemoClass(context))
        Assert.assertEquals("Hello", exampleClass.getString())

        every { exampleClass.getString() } returns "Hello 1"

        Assert.assertEquals("Hello 1", exampleClass.getString())
    }
}
package com.example.espressotest

import io.mockk.every
import io.mockk.spyk
import org.junit.Assert.assertEquals
import org.junit.Test


class ListTest {
    @Test
    fun test_list() {
        val listSpy: MutableList<String> = spyk(ArrayList())
        listSpy.add("sample")
        assertEquals("sample", listSpy[0])
        every { listSpy[0] } returns "sample 1"
        assertEquals("sample 1", listSpy[0])
    }
}
package com.example.espressotest

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.PerformException
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.contrib.RecyclerViewActions
import androidx.test.espresso.contrib.RecyclerViewActions.scrollToPosition
import androidx.test.espresso.matcher.BoundedMatcher
import androidx.test.espresso.matcher.RootMatchers
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.ext.junit.rules.ActivityScenarioRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.hamcrest.Matcher
import org.hamcrest.Matchers
import org.junit.After
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith


@RunWith(AndroidJUnit4::class)
class ListActivityTest {
    @get:Rule
    var activityScenarioRule = ActivityScenarioRule(ListActivity::class.java)

    private lateinit var activity: ListActivity

    @Before
    fun setUp() {
        activityScenarioRule.scenario.onActivity {
            activity = it
        }
    }

    @Test
    fun testRecyclerVisible() {
        onView(withId(R.id.recyclerView)).inRoot(
            RootMatchers.withDecorView(
                Matchers.`is`(activity.window.decorView)
            )
        ).check(matches(isDisplayed()))
    }

    @Test
    fun testCaseForRecyclerScrollLast() {
        val recyclerView: RecyclerView = activity.findViewById(R.id.recyclerView)
        val itemCount = recyclerView.adapter!!.itemCount

        onView(withId(R.id.recyclerView))
            .inRoot(
                RootMatchers.withDecorView(
                    Matchers.`is`(activity.window.decorView)
                )
            )
            .perform(scrollToPosition<RecyclerView.ViewHolder>(itemCount - 1))
    }

    @Test
    fun testCaseForRecyclerScrollToItem() {
        onView(withId(R.id.recyclerView)).perform(
            RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(
                3,
                click()
            )
        )
        onView(withText("Dialer")).check(matches(isDisplayed()))

        onView(withId(R.id.recyclerView)).perform(
            RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(
                10,
                click()
            )
        )
        onView(withText("Alert1")).check(matches(isDisplayed()))

//        onView(withId(R.id.recyclerView)).perform(
//            RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(
//                11,
//                click()
//            )
//        )
//        onView(withText("Map1")).check(matches(isDisplayed()))

        onView(withId(R.id.recyclerView))
            .perform(scrollToPosition<RecyclerView.ViewHolder>(11))
            .check(matches(positionOnView(11, withText("Map1"), R.id.textView)))
    }

    @Test
    fun testClickItemWithText() {
        onView(withId(R.id.recyclerView)).perform(
            RecyclerViewActions.actionOnItem<RecyclerView.ViewHolder>(
                hasDescendant(withText("Info")),
                click()
            )
        )
    }

    @Test
    fun testCaseForRecyclerClick() {
        onView(withId(R.id.recyclerView)).inRoot(
            RootMatchers.withDecorView(
                Matchers.`is`(activity.window.decorView)
            )
        ).perform(
            RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(
                0,
                click()
            )
        )
    }

    @Test(expected = PerformException::class)
    fun testItemWithTextDoesNotExist() {
        onView(withId(R.id.recyclerView)).perform(
            RecyclerViewActions.scrollTo<RecyclerView.ViewHolder>(
                hasDescendant(withText("not in the list"))
            )
        )
    }

    @After
    fun tearDown() {
        activityScenarioRule.scenario.close()
    }

    private fun positionOnView(
        position: Int,
        itemMatcher: Matcher<View?>,
        targetViewId: Int
    ): Matcher<View?>? {
        return object : BoundedMatcher<View?, RecyclerView>(RecyclerView::class.java) {
            override fun describeTo(description: org.hamcrest.Description?) {
                description?.appendText("view id $itemMatcher at position $position")
            }

            override fun matchesSafely(recyclerView: RecyclerView): Boolean {
                val viewHolder = recyclerView.findViewHolderForAdapterPosition(position)
                val targetView: View = viewHolder!!.itemView.findViewById(targetViewId)
                return itemMatcher.matches(targetView)
            }
        }
    }
}
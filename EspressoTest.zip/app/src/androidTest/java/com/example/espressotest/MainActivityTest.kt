package com.example.espressotest

import android.content.ComponentName
import android.content.Intent
import android.content.pm.ActivityInfo
import android.view.WindowManager
import androidx.lifecycle.Lifecycle
import androidx.test.core.app.ActivityScenario
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions
import androidx.test.espresso.action.ViewActions.closeSoftKeyboard
import androidx.test.espresso.action.ViewActions.typeText
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.RootMatchers.withDecorView
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.hamcrest.CoreMatchers.`is`
import org.hamcrest.CoreMatchers.not
import org.hamcrest.MatcherAssert.assertThat
import org.junit.After
import org.junit.Assert
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class MainActivityTest {
    lateinit var scenario: ActivityScenario<MainActivity>
    private lateinit var activity: MainActivity

    @Before
    fun setup() {
        scenario = ActivityScenario.launch(MainActivity::class.java)
        scenario.onActivity {
            activity = it
        }
        scenario.moveToState(Lifecycle.State.CREATED)
        scenario.moveToState(Lifecycle.State.RESUMED)
    }

    @Test
    fun testState() {
        assertThat(scenario.state, `is`(Lifecycle.State.RESUMED))
    }

    @Test
    fun inputView() {
        onView(withId(R.id.textView)).check(matches(withText("Welcome")))
    }

    @Test
    fun inputViews() {
        onView(withId(R.id.userName)).perform(typeText("98676588"))
        onView(withId(R.id.password)).perform(typeText("testPassword"), closeSoftKeyboard())

        onView(withId(R.id.userName)).check(matches(withText("98676588")))
        onView(withId(R.id.password)).check(matches(withText("testPassword")))

        onView(withId(R.id.verify)).perform(ViewActions.click())

        onView(withText("Success")).inRoot(
            withDecorView(
                not(
                    activity.window.decorView
                )
            )
        ).check(matches(isDisplayed()))
    }

    @Test
    fun verifyLaunchMode() {
        val componentName = activity.componentName
        val launchMode = activity.packageManager.getActivityInfo(componentName, 0).launchMode
        Assert.assertEquals(ActivityInfo.LAUNCH_MULTIPLE, launchMode)
    }

    @Test
    fun verifyWindowSoftInputMode() {
        val componentName = activity.componentName
        val softInputMode = activity.packageManager.getActivityInfo(componentName, 0).softInputMode
        Assert.assertEquals(
            WindowManager.LayoutParams.SOFT_INPUT_ADJUST_UNSPECIFIED,
            softInputMode
        )
    }

    @Test
    fun verifyCategory() {
        val intent = Intent(Intent.ACTION_MAIN)
        intent.addCategory(Intent.CATEGORY_LAUNCHER)
        val context = InstrumentationRegistry.getInstrumentation().context
        val resolveInfoList = context.packageManager.queryIntentActivities(intent, 0)

        val componentName = activity.componentName

        Assert.assertNotNull(resolveInfoList)

        val found = resolveInfoList.find { resolveInfo ->
            componentName.className ==
                    ComponentName(
                        resolveInfo.activityInfo.packageName,
                        resolveInfo.activityInfo.name
                    ).className
        }

        Assert.assertNotNull(found)
    }

    @After
    fun tearDown() {
        scenario.close()
    }
}
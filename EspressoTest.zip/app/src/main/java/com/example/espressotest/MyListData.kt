package com.example.espressotest

class MyListData(var description: String, var imgId: Int)
package com.example.espressotest

import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        verify.setOnClickListener {
            when {
                TextUtils.isEmpty(userName.text) -> {
                    Toast.makeText(this, "User name can not be empty", Toast.LENGTH_SHORT).show()
                }
                TextUtils.isEmpty(password.text) -> {
                    Toast.makeText(this, "Password can not be empty", Toast.LENGTH_SHORT).show()
                }
                else -> {
                    Toast.makeText(this, "Success", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this,ListActivity::class.java))
                }
            }
        }
    }
}
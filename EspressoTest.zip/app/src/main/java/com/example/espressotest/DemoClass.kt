package com.example.espressotest

import android.content.Context

class DemoClass(context: Context) {

    fun getString(): String {
        return "Hello"
    }
}


package com.example.espressotest

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_list.*


class ListActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)

        val myListData: Array<MyListData> = arrayOf(
            MyListData("Email", android.R.drawable.ic_dialog_email),
            MyListData("Info", android.R.drawable.ic_dialog_info),
            MyListData("Delete", android.R.drawable.ic_delete),
            MyListData("Dialer", android.R.drawable.ic_dialog_dialer),
            MyListData("Alert", android.R.drawable.ic_dialog_alert),
            MyListData("Map1", android.R.drawable.ic_dialog_map),
            MyListData("Email1", android.R.drawable.ic_dialog_email),
            MyListData("Info1", android.R.drawable.ic_dialog_info),
            MyListData("Delete1", android.R.drawable.ic_delete),
            MyListData("Dialer1", android.R.drawable.ic_dialog_dialer),
            MyListData("Alert1", android.R.drawable.ic_dialog_alert),
            MyListData("Map1", android.R.drawable.ic_dialog_map)
        )

        val adapter = MyListAdapter(myListData)
        recyclerView.setHasFixedSize(true)
        recyclerView.adapter = adapter
    }
}
package com.example.espressotest

object Sum {
    fun add(a: Int, b: Int) = a + b
}
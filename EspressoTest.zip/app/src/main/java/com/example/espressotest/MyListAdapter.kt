package com.example.espressotest

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView


class MyListAdapter(private val listData: Array<MyListData>) :
    RecyclerView.Adapter<MyListAdapter.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val listItem: View = layoutInflater.inflate(R.layout.list_item, parent, false)
        return ViewHolder(listItem)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val myListData = listData[position]
        holder.textView.text = listData[position].description
        holder.imageView.setImageResource(listData[position].imgId)
        holder.itemView.setOnClickListener { view ->
            Toast.makeText(
                view.context,
                "click on item: " + myListData.description,
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun getItemCount(): Int {
        return listData.size
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var imageView = itemView.findViewById(R.id.imageView) as ImageView
        var textView = itemView.findViewById(R.id.textView) as TextView
    }
}